#!/usr/bin/env python3
"""Convert v1 debug app's shared_prefs XML to the v2 JSON import format.
Run locally AFTER pulling XML via Android Debug Bridge; never upload private history."""
import json
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path


def convert(src: Path, dest: Path):
    root = ET.parse(src).getroot()
    if root.tag != 'map':
        raise ValueError('Invalid Android preferences XML')
    prefs = {}
    for item in root:
        key = item.attrib.get('name')
        if not key:
            continue
        if item.tag == 'string':
            prefs[key] = item.text or ''
        elif item.tag in ('int', 'long'):
            prefs[key] = int(item.attrib['value'])
        elif item.tag == 'boolean':
            prefs[key] = item.attrib['value'].lower() == 'true'
        elif item.tag == 'float':
            # AppStore v1 stored nicotine and duration as bitwise longs.
            prefs[key] = float(item.attrib['value'])
    history = json.loads(prefs.get('sessions_json', '[]'))
    if not isinstance(history, list):
        raise ValueError('Invalid sessions history')
    # Preserve previously reached automatically-calculated stage on conversion.
    if prefs.get('program_started') and prefs.get('auto_progress', True):
        start = max(15, int(prefs.get('start_interval', 60)))
        target = max(start, int(prefs.get('target_interval', 240)))
        step_before = max(5, int(prefs.get('step_before_2h', 15)))
        step_after = max(5, int(prefs.get('step_after_2h', 30)))
        stages = [start]
        while stages[-1] < target and len(stages) <= 100:
            current = stages[-1]
            stages.append(min(target, current + (step_before if current < 120 else step_after)))
        begin = int(prefs.get('program_start', 0))
        days = max(1, int(prefs.get('stage_days', 2)))
        index = max(0, min(len(stages)-1, (int(time.time()*1000)-begin)//(days*86400000))) if begin > 0 else 0
        prefs['manual_stage_interval'] = stages[index]
        prefs['auto_progress'] = False
    prefs['stage_migrated_v2'] = True
    dest.write_text(json.dumps({'schema': 2, 'app': 'NicotineIntervals', 'prefs': prefs}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Converted {len(history)} sessions -> {dest}')


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('Usage: python migrate_v1_debug.py nicotine-v1.xml nicotine-v2-backup.json')
    convert(Path(sys.argv[1]), Path(sys.argv[2]))
