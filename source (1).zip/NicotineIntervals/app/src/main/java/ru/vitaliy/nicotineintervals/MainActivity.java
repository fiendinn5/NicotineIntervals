package ru.vitaliy.nicotineintervals;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int EXPORT=503, IMPORT=504;
    private AppStore store;
    private LinearLayout root;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int ink, muted, surface, background, accent, accentSoft, border, green, orange;
    private boolean dark;
    private TextView timerText, timerHint, elapsedText, impactMain, impactStatus, impactDetail, vascularNote;
    private ProgressBar impactProgress;
    private ProgressBar timerProgress;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        store=new AppStore(this); colors();
        setTheme(dark?android.R.style.Theme_Material_NoActionBar:android.R.style.Theme_Material_Light_NoActionBar);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);
        showHome(); handler.post(tick); safeStartService();
    }
    @Override protected void onResume(){super.onResume(); if(store!=null) safeStartService();}
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==4001 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) safeStartService();
    }
    @Override protected void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
    private final Runnable tick=new Runnable(){@Override public void run(){
        if(root!=null && "home".equals(root.getTag()))refreshHomeValues();
        handler.postDelayed(this,1000);
    }};
    private void safeStartService(){try{StatusService.start(this);}catch(Exception ignored){}}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void colors(){
        String setting=store.theme();
        boolean sys=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        dark="dark".equals(setting)||("system".equals(setting)&&sys);
        ink=Color.parseColor(dark?"#F0F3FC":"#182137");
        muted=Color.parseColor(dark?"#ABB5CA":"#69758B");
        surface=Color.parseColor(dark?"#1D2536":"#FFFFFF");
        background=Color.parseColor(dark?"#101726":"#F5F7FC");
        accent=Color.parseColor(dark?"#93ABFF":"#4765D7");
        accentSoft=Color.parseColor(dark?"#2A395B":"#E7EDFF");
        border=Color.parseColor(dark?"#323E56":"#E7EAF1");
        green=Color.parseColor(dark?"#79D7AC":"#17845B");
        orange=Color.parseColor(dark?"#F6C078":"#B96A1B");
        getWindow().setStatusBarColor(background);getWindow().setNavigationBarColor(background);
        int flags=dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable outline(int color,int stroke,int radius){GradientDrawable d=shape(color,radius);d.setStroke(dp(1),stroke);return d;}
    private TextView text(String str,int size,boolean bold,int color){
        TextView t=new TextView(this);t.setText(str);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private TextView label(String s){return text(s,13,false,muted);}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout card(){
        LinearLayout c=column();c.setPadding(dp(18),dp(18),dp(18),dp(18));c.setBackground(outline(surface,border,22));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(13);c.setLayoutParams(p);return c;
    }
    private void pad(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private Button button(String s,boolean primary){
        Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(primary?Color.WHITE:accent);b.setBackground(primary?shape(Color.parseColor("#4765D7"),15):outline(accentSoft,border,15));
        b.setPadding(dp(12),dp(4),dp(12),dp(4));b.setMinHeight(dp(52));
        return b;
    }
    private ProgressBar progress(int color){
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(1000);p.setProgress(0);
        p.setProgressTintList(ColorStateList.valueOf(color));p.setProgressBackgroundTintList(ColorStateList.valueOf(border));
        return p;
    }
    private void base(String tag,String title,String subtitle){
        colors();LinearLayout screen=column();screen.setBackgroundColor(background);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
        root=column();root.setTag(tag);root.setPadding(dp(18),dp(16),dp(18),dp(26));scroll.addView(root);
        screen.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=horizontal();nav.setPadding(dp(8),dp(9),dp(8),dp(10));nav.setBackgroundColor(surface);
        String[] names={"Сегодня","Статистика","История","Настройки"};
        int[] icons={R.drawable.ic_nav_clock,R.drawable.ic_nav_stats,R.drawable.ic_nav_history,R.drawable.ic_nav_settings};
        for(int i=0;i<names.length;i++){
            final int selected=i;
            LinearLayout item=column();item.setGravity(Gravity.CENTER);
            boolean active=(tag.equals("home")&&i==0)||(tag.equals("stats")&&i==1)||(tag.equals("history")&&i==2)||(tag.equals("settings")&&i==3);
            ImageView symbol=new ImageView(this);symbol.setImageResource(icons[i]);
            symbol.setImageTintList(ColorStateList.valueOf(active?accent:muted));
            LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(dp(23),dp(23));iconParams.bottomMargin=dp(5);
            TextView small=text(names[i],11,active,active?accent:muted);small.setGravity(Gravity.CENTER);
            item.addView(symbol,iconParams);item.addView(small);item.setPadding(dp(1),0,dp(1),0);
            item.setContentDescription(names[i]);
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(55),1));
            item.setOnClickListener(v->{if(selected==0)showHome();else if(selected==1)showStats();else if(selected==2)showHistory();else showSettings();});
        }
        screen.addView(nav);setContentView(screen);
        // Android 15 enforces edge-to-edge for targetSdk 35. Keep content clear of system bars.
        if(Build.VERSION.SDK_INT>=35) screen.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(0,insets.getSystemWindowInsetTop(),0,insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.addView(text(title,30,true,ink));
        TextView sub=text(subtitle,13,false,muted);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(5);lp.bottomMargin=dp(22);sub.setLayoutParams(lp);root.addView(sub);
    }
    private TextView chip(String s,int color){TextView t=text(s,12,true,color);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),dp(7),dp(10),dp(7));t.setBackground(shape(accentSoft,12));return t;}
    private String minutes(int m){if(m<60)return m+" мин";return m%60==0?(m/60)+" ч":(m/60)+" ч "+(m%60)+" мин";}
    private String countdown(long ms){long x=Math.max(0,ms/1000);return String.format(Locale.getDefault(),"%02d:%02d:%02d",x/3600,(x%3600)/60,x%60);}
    private String mg(double x){return String.format(Locale.getDefault(),"%.2f",x);}
    private void title(LinearLayout parent,String s){TextView t=text(s,19,true,ink);parent.addView(t);pad(parent,12);}
    private void infoLine(LinearLayout parent,String name,String value){
        LinearLayout row=horizontal();TextView a=text(name,14,false,muted),b=text(value,14,true,ink);
        row.addView(a,new LinearLayout.LayoutParams(0,-2,1));row.addView(b);parent.addView(row);pad(parent,10);
    }

    private void showHome(){
        base("home","Интервалы","Меньше тяг. Длиннее паузы. Твой прогресс.");
        if(!store.programStarted()) {
            LinearLayout intro=card();title(intro,"Начни в своём темпе");intro.addView(label("Отмечай реальные сеансы. Цель — постепенно увеличивать паузы, без штрафов за досрочные записи."));
            pad(intro,13);Button start=button("Начать программу",true);
            start.setOnClickListener(v->{store.setProgramStarted(true);store.setProgramStart(System.currentTimeMillis());store.setManualStageInterval(store.startInterval());store.setStageStartTime(System.currentTimeMillis());showHome();});
            intro.addView(start);root.addView(intro);
        }
        LinearLayout hero=column();hero.setPadding(dp(22),dp(21),dp(22),dp(22));
        GradientDrawable gradient=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.parseColor("#304CAD"),Color.parseColor("#6A75E7")});
        gradient.setCornerRadius(dp(24));hero.setBackground(gradient);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.bottomMargin=dp(14);hero.setLayoutParams(hp);
        TextView lead=text("ДО ПЛАНОВОГО ИНТЕРВАЛА",12,true,Color.parseColor("#D9E4FF"));hero.addView(lead);pad(hero,12);
        timerText=text("--:--:--",43,true,Color.WHITE);timerText.setGravity(Gravity.CENTER);hero.addView(timerText);
        timerHint=text("",13,false,Color.parseColor("#E2E9FF"));timerHint.setGravity(Gravity.CENTER);hero.addView(timerHint);pad(hero,17);
        timerProgress=progress(Color.parseColor("#E0FFEB"));hero.addView(timerProgress,new LinearLayout.LayoutParams(-1,dp(9)));pad(hero,13);
        elapsedText=text("",13,false,Color.WHITE);hero.addView(elapsedText);pad(hero,15);
        Button log=button("＋  Записать сеанс",true);log.setBackground(shape(Color.WHITE,15));log.setTextColor(Color.parseColor("#304CAD"));
        log.setOnClickListener(v->sessionDialog());hero.addView(log);root.addView(hero);

        List<Integer> stages=Model.stages(store.startInterval(),store.targetInterval(),store.stepBefore2h(),store.stepAfter2h());
        int idx=Model.currentStageIndex(store,System.currentTimeMillis());
        LinearLayout st=card();LinearLayout stRow=horizontal();
        LinearLayout left=column();left.addView(text("Текущая ступень",14,false,muted));left.addView(text(minutes(Model.currentInterval(store,System.currentTimeMillis())),25,true,ink));
        stRow.addView(left,new LinearLayout.LayoutParams(0,-2,1));stRow.addView(chip((idx+1)+" / "+stages.size()+" этапов",accent));st.addView(stRow);
        pad(st,8);st.addView(label("Конечная цель: "+minutes(store.targetInterval())));
        if(idx<stages.size()-1 && StatsEngine.readyForNextStage(store.getSessions(),Model.currentInterval(store,System.currentTimeMillis()),store.stageStartTime())) {
            pad(st,13);Button next=button("Перейти к "+minutes(stages.get(idx+1)),false);
            next.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Следующий этап")
                    .setMessage("Установить план "+minutes(stages.get(idx+1))+"? История и текущий таймер сохранятся.")
                    .setPositiveButton("Перейти",(d,w)->{store.setManualStageInterval(stages.get(idx+1));store.setStageStartTime(System.currentTimeMillis());showHome();})
                    .setNegativeButton("Позже",null).show());st.addView(next);
        }
        root.addView(st);

        long now=System.currentTimeMillis();List<Session> all=store.getSessions();
        StatsEngine.Stats today=StatsEngine.since(all,StatsEngine.dayStart(now),StatsEngine.daysBefore(now,-1));
        StatsEngine.Stats yesterday=StatsEngine.since(all,StatsEngine.daysBefore(now,1),StatsEngine.dayStart(now));
        LinearLayout c=card();title(c,"Сегодня");
        LinearLayout first=horizontal();first.addView(metric("Сеансов",String.valueOf(today.sessions)),new LinearLayout.LayoutParams(0,-2,1));
        first.addView(metric("Затяжек",String.valueOf(today.puffs)),new LinearLayout.LayoutParams(0,-2,1));c.addView(first);pad(c,12);
        LinearLayout second=horizontal();second.addView(metric("Средняя пауза",today.measuredIntervals==0?"—":minutes((int)Math.round(today.avgIntervalMin))),new LinearLayout.LayoutParams(0,-2,1));
        second.addView(metric("План соблюдён",today.measuredIntervals==0?"—":today.metPlan+" из "+today.measuredIntervals),new LinearLayout.LayoutParams(0,-2,1));c.addView(second);
        if(today.estimatedSessions>0) {pad(c,10);c.addView(label("Оценка по настроенному устройству: ≈"+mg(today.estimatedMg)+" мг в аэрозоле/жидкости за "+today.estimatedSessions+" сеанс(ов)."));}
        if(today.measuredIntervals>0 && yesterday.measuredIntervals>0) {
            pad(c,10);int delta=(int)Math.round(today.avgIntervalMin-yesterday.avgIntervalMin);
            c.addView(text((delta>=0?"↑ +":"↓ ")+Math.abs(delta)+" мин к средней паузе относительно вчера",13,true,delta>=0?green:orange));
        }
        LinearLayout third=horizontal();pad(c,12);
        third.addView(metric("Лучшая пауза",today.measuredIntervals==0?"—":minutes((int)Math.round(today.longestIntervalMin))),new LinearLayout.LayoutParams(0,-2,1));
        third.addView(metric("Досрочных",String.valueOf(today.earlier)),new LinearLayout.LayoutParams(0,-2,1));c.addView(third);
        root.addView(c);

        LinearLayout model=card();title(model,"Сосудистое влияние никотина");
        model.addView(label("Условный индекс недавних сеансов · шкала 0–100"));pad(model,12);
        LinearLayout impactRow=horizontal();
        impactMain=text("—",36,true,ink);
        impactRow.addView(impactMain,new LinearLayout.LayoutParams(0,-2,1));
        impactStatus=chip("Нет данных",accent);impactRow.addView(impactStatus);
        model.addView(impactRow);pad(model,12);
        impactProgress=progress(accent);
        model.addView(impactProgress,new LinearLayout.LayoutParams(-1,dp(11)));pad(model,13);
        impactDetail=text("",14,false,ink);model.addView(impactDetail);pad(model,13);
        vascularNote=text("",13,false,muted);
        vascularNote.setPadding(dp(13),dp(13),dp(13),dp(13));
        vascularNote.setBackground(shape(accentSoft,14));model.addView(vascularNote);pad(model,12);
        TextView explain=text("ⓘ Что означает индекс и как он считается →",13,true,accent);
        explain.setOnClickListener(v->showExposureExplanation());model.addView(explain);
        if(!store.doseEstimateEnabled()){
            pad(model,10);Button enable=button("Настроить оценку дозы →",false);
            enable.setOnClickListener(v->showSettings());model.addView(enable);
        }
        root.addView(model);
        LinearLayout history=card();title(history,"Последние сеансы");recent(history,4);pad(history,8);
        Button allHistory=button("Вся история →",false);allHistory.setOnClickListener(v->showHistory());history.addView(allHistory);root.addView(history);
        refreshHomeValues();
    }
    private LinearLayout metric(String label,String number){
        LinearLayout c=column();c.setPadding(dp(12),dp(11),dp(8),dp(11));c.setBackground(shape(accentSoft,15));
        c.addView(text(number,21,true,ink));c.addView(text(label,12,false,muted));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.rightMargin=dp(8);c.setLayoutParams(p);return c;
    }
    private void refreshHomeValues(){
        if(timerText==null||root==null||!"home".equals(root.getTag()))return;
        long now=System.currentTimeMillis();List<Session> sessions=store.getSessions();
        if(sessions.isEmpty()) {
            timerText.setText("—");timerHint.setText("Добавь первый сеанс для запуска отсчёта");
            elapsedText.setText("Текущий план: "+minutes(Model.currentInterval(store,now)));timerProgress.setProgress(0);
        } else {
            Session last=sessions.get(sessions.size()-1);
            int interval=last.plannedIntervalMin;long passed=Math.max(0,now-last.timestamp),remaining=interval*60_000L-passed;
            timerText.setText(remaining>0?countdown(remaining):"План выдержан ✓");
            timerText.setTextSize(remaining>0?43:27);
            timerHint.setText(remaining>0?"Можно продолжать паузу и после таймера":"Ты можешь увеличить паузу ещё больше");
            timerProgress.setProgress((int)Math.max(0,Math.min(1000,1000.0*passed/Math.max(1,interval*60_000L))));
            elapsedText.setText("Прошло: "+minutes((int)(passed/60000))+"    ·    План: "+minutes(interval));
        }
        updateExposureCard(sessions,now);
    }

    private int impactColor(int score) {
        if (score <= 20) return muted;
        if (score <= 40) return accent;
        if (score <= 60) return Color.parseColor(dark?"#E1BE74":"#A87921");
        if (score <= 80) return orange;
        return Color.parseColor(dark?"#ED8D99":"#C94D65");
    }
    private void updateExposureCard(List<Session> sessions,long now){
        if(impactMain==null || impactDetail==null || vascularNote==null ||
                impactStatus==null || impactProgress==null) return;
        VascularImpactIndex.Snapshot x=VascularImpactIndex.snapshot(sessions,now);
        if (!x.hasRecentSessions) {
            impactMain.setText("—");
            impactStatus.setText("Нет недавних сеансов");
            impactStatus.setTextColor(muted);
            impactDetail.setText("За последние 12 часов нет записей с расчётной дозой.");
            vascularNote.setText("Индекс не измеряет состояние сосудов. Даже при нулевом значении " +
                    "вред аэрозоля или длительные эффекты не исключены.");
            impactProgress.setProgress(0);
            impactProgress.setProgressTintList(ColorStateList.valueOf(muted));
        } else if(x.missingRecentDoses > 0){
            impactMain.setText("—");
            impactStatus.setText("Неполные данные");
            impactStatus.setTextColor(muted);
            impactDetail.setText("За последние 8 часов у "+x.missingRecentDoses+
                    " сеанс(ов) отсутствует оценка дозы. Для новых сеансов включи мг/тягу в настройках.");
            vascularNote.setText("Старой истории не присваиваются вымышленные дозы. " +
                    "Индекс появится, когда данных будет достаточно.");
            impactProgress.setProgress(0);
            impactProgress.setProgressTintList(ColorStateList.valueOf(muted));
        } else if(x.canShowIndex()) {
            int score=x.score;
            int color=impactColor(score);
            impactMain.setText(score+" / 100");
            impactStatus.setText(VascularImpactIndex.level(score));
            impactStatus.setTextColor(color);
            impactProgress.setProgress(score*10);
            impactProgress.setProgressTintList(ColorStateList.valueOf(color));
            String last=(x.lastDoseMg!=null && Double.isFinite(x.lastDoseMg) && x.lastDoseMg>=0)
                    ? "Последний сеанс: "+x.lastPuffs+" тяг · ~"+mg(x.lastDoseMg)+" мг по настройке. "
                    : "";
            impactDetail.setText(last+"При паузе без новых тяг: через 45 мин ~"+
                    x.afterMinutes(45)+"/100, через 90 мин ~"+x.afterMinutes(90)+"/100.");
            vascularNote.setText("Это УСЛОВНЫЙ индекс интенсивности недавнего воздействия никотина, " +
                    "а не процент сужения сосудов, их повреждения или персональный риск. " +
                    "Границы уровней не подтверждены клинически.");
        } else {
            impactMain.setText("—");
            impactStatus.setText("Нет оценки дозы");
            impactStatus.setTextColor(muted);
            impactDetail.setText("Включи примерную мг/тягу в настройках устройства для будущих сеансов.");
            vascularNote.setText("Невозможно вычислить индекс без оценки дозы за недавние сеансы.");
            impactProgress.setProgress(0);
            impactProgress.setProgressTintList(ColorStateList.valueOf(muted));
        }
    }
    private void showExposureExplanation(){
        new AlertDialog.Builder(this)
            .setTitle("Сосудистое влияние: что означает индекс")
            .setMessage("Это экспериментальный индикатор недавней никотиновой нагрузки (0–100), " +
                "а не медицинская оценка сужения сосудов. Значения 20/40/60/80 и подписи «высокий», " +
                "«умеренный» — условные категории модели, а не клинические пороги. " +
                "По затяжкам нельзя измерить давление, изменение диаметра артерий или повреждение эндотелия.\n\n" +
                "Для каждого сеанса берётся ВВЕДЁННАЯ ПРИМЕРНАЯ доза: количество тяг × мг/тягу. " +
                "Пиковый вклад: 100 × (1 − exp(−доза/0,35 мг)). " +
                "Условное затухание: половина вклада каждые 45 минут. " +
                "Перекрывающиеся сеансы объединяются с насыщением, чтобы число не превышало 100. " +
                "Коэффициент 0,35 мг и 45 минут — параметры визуализации, а НЕ " +
                "доказанные зависимости «доза → сужение сосудов» или скорость восстановления.\n\n" +
                "У вейпинга с никотином возможны кратковременные изменения пульса, давления " +
                "и артериальной жёсткости. Низкий или нулевой индекс не означает безопасность: " +
                "модель не оценивает хронические риски и эффекты самого аэрозоля. " +
                "Дозировка мг/тягу одноразки также может существенно отличаться от оценки.\n\n" +
                "Для индивидуальной реакции полезны реальные измерения пульса и АД, " +
                "но и они не измеряют процент сужения сосудов. " +
                "При боли в груди, сильной одышке или неврологических симптомах нужна срочная помощь.")
            .setPositiveButton("Понятно",null)
            .show();
    }

    private void sessionDialog(){
        if(!store.programStarted()){Toast.makeText(this,"Сначала начни программу",Toast.LENGTH_SHORT).show();return;}
        LinearLayout content=column();content.setPadding(dp(22),dp(10),dp(22),0);
        content.addView(label("Количество тяг"));pad(content,5);
        EditText count=new EditText(this);count.setSingleLine(true);count.setInputType(InputType.TYPE_CLASS_NUMBER);
        count.setText(String.valueOf(store.referencePuffs()));content.addView(count);pad(content,10);
        LinearLayout chips=horizontal();int[] values={3,5,7,9,10};
        for(int value:values){TextView b=chip(String.valueOf(value),accent);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(39),1);p.rightMargin=dp(4);chips.addView(b,p);b.setOnClickListener(v->count.setText(String.valueOf(value)));}
        content.addView(chips);pad(content,13);
        List<Session> all=store.getSessions();long now=System.currentTimeMillis();
        if(!all.isEmpty()){
            Session last=all.get(all.size()-1);long delta=Math.max(0,now-last.timestamp);
            int diff=(int)(delta/60000)-last.plannedIntervalMin;
            content.addView(text("Пауза: "+minutes((int)(delta/60000))+" · "+(diff>=0?"+":"")+diff+" мин к плану",13,true,diff>=0?green:orange));
        }
        if(store.doseEstimateEnabled())content.addView(label("Доза: ≈"+mg(store.mgPerPuff())+" мг/тяга (пользовательская оценка)"));
        new AlertDialog.Builder(this).setTitle("Записать сеанс").setView(content)
                .setPositiveButton("Сохранить",(dialog,which)->{
                    int p=readInt(count,store.referencePuffs());if(p<1 || p>500){Toast.makeText(this,"Допустимо 1–500 тяг",Toast.LENGTH_LONG).show();return;}
                    long time=System.currentTimeMillis();int interval=Model.currentInterval(store,time);
                    Session s=new Session(time,p,store.strength(),store.deviceType(),store.puffSeconds(),interval);
                    s.deviceName=store.deviceName();s.deviceMode=store.deviceMode();
                    if(store.doseEstimateEnabled()) {s.mgPerPuff=store.mgPerPuff();s.estimatedNicotineMg=p*store.mgPerPuff();}
                    store.addSession(s);AlarmScheduler.schedule(this,time+interval*60000L);safeStartService();showHome();
                }).setNegativeButton("Отмена",null).show();
    }
    private void recent(LinearLayout parent,int max){
        List<Session> ss=store.getSessions();if(ss.isEmpty()){parent.addView(label("Записей пока нет"));return;}
        SimpleDateFormat date=new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault());
        for(int i=ss.size()-1,n=0;i>=0&&n<max;i--,n++){
            Session x=ss.get(i);LinearLayout row=column();row.setPadding(0,dp(9),0,dp(9));
            row.addView(text(date.format(new Date(x.timestamp))+"  ·  "+x.puffs+" тяг"+(x.estimatedNicotineMg!=null?"  ·  ≈"+mg(x.estimatedNicotineMg)+" мг":""),14,true,ink));
            if(i>0) {
                Session prev=ss.get(i-1);int actual=(int)Math.round((x.timestamp-prev.timestamp)/60000.0);
                int difference=actual-prev.plannedIntervalMin;
                row.addView(text("Интервал "+minutes(Math.max(0,actual))+"  ·  "+(difference>=0?"+":"")+difference+" мин к плану",12,false,difference>=0?green:orange));
            } else row.addView(label("Первая запись"));
            row.setOnClickListener(v->editSession(x));
            parent.addView(row);if(n<max-1&&i>0){View line=new View(this);line.setBackgroundColor(border);parent.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}
        }
    }
    private void showHistory(){base("history","История","Записи можно открыть, исправить или удалить.");
        LinearLayout c=card();title(c,"Записанные сеансы");recent(c,Integer.MAX_VALUE);root.addView(c);
    }
    private void editSession(Session selected){
        EditText count=edit(String.valueOf(selected.puffs),true);
        LinearLayout content=column();content.setPadding(dp(20),dp(8),dp(20),0);
        content.addView(field("Количество тяг",count));
        content.addView(label("Время и настройки устройства сохраняются. Пересчёт дозы возможен только для сеансов, где она была задана."));
        new AlertDialog.Builder(this).setTitle("Исправить сеанс").setView(content)
            .setPositiveButton("Сохранить",(d,w)->{
                int p=readInt(count,selected.puffs);if(p<1||p>500){Toast.makeText(this,"Допустимо 1–500 тяг",Toast.LENGTH_LONG).show();return;}
                List<Session> sessions=store.getSessions();
                for(Session s:sessions)if(s.timestamp==selected.timestamp){s.puffs=p;if(s.mgPerPuff!=null)s.estimatedNicotineMg=p*s.mgPerPuff;break;}
                store.saveSessions(sessions);if("home".equals(root.getTag()))showHome();else showHistory();
            })
            .setNeutralButton("Удалить",(d,w)->new AlertDialog.Builder(this)
                    .setTitle("Удалить этот сеанс?").setMessage("История интервалов будет пересчитана. Отменить нельзя.")
                    .setPositiveButton("Удалить",(dd,ww)->{
                        store.removeSession(selected.timestamp);
                        AlarmScheduler.cancel(this);
                        List<Session> current=store.getSessions();
                        if(current.isEmpty())StatusService.stop(this);
                        else {Session last=current.get(current.size()-1);long due=last.timestamp+last.plannedIntervalMin*60000L;if(due>System.currentTimeMillis())AlarmScheduler.schedule(this,due);safeStartService();}
                        if("home".equals(root.getTag()))showHome();else showHistory();
                    }).setNegativeButton("Отмена",null).show())
            .setNegativeButton("Отмена",null).show();
    }
    private void showStats(){
        base("stats","Статистика","Реальные интервалы и затяжки, без медицинских догадок.");
        long now=System.currentTimeMillis();List<Session> all=store.getSessions();
        LinearLayout chart=card();title(chart,"Затяжки · последние 7 дней");
        chart.addView(new WeeklyChartView(this,all,now,ink,accent,WeeklyChartView.PUFFS),new LinearLayout.LayoutParams(-1,dp(188)));
        root.addView(chart);
        LinearLayout intervalChart=card();title(intervalChart,"Средняя пауза · последние 7 дней");
        intervalChart.addView(new WeeklyChartView(this,all,now,ink,green,WeeklyChartView.INTERVALS),new LinearLayout.LayoutParams(-1,dp(188)));
        root.addView(intervalChart);
        statsCard("Сегодня",StatsEngine.since(all,StatsEngine.dayStart(now),StatsEngine.daysBefore(now,-1)));
        statsCard("7 дней",StatsEngine.since(all,StatsEngine.daysBefore(now,6),StatsEngine.daysBefore(now,-1)));
        statsCard("30 дней",StatsEngine.since(all,StatsEngine.daysBefore(now,29),StatsEngine.daysBefore(now,-1)));
        LinearLayout note=card();note.addView(label("Интервал = время от предыдущего сеанса. Проверка плана ведётся относительно плана, который действовал после предыдущего сеанса. Паузы более 24 часов исключены из среднего как возможный перерыв в ведении дневника."));root.addView(note);
    }
    private void statsCard(String name,StatsEngine.Stats x){
        LinearLayout c=card();title(c,name);infoLine(c,"Сеансов",String.valueOf(x.sessions));infoLine(c,"Затяжек",String.valueOf(x.puffs));
        infoLine(c,"Средний интервал",x.measuredIntervals==0?"—":minutes((int)Math.round(x.avgIntervalMin)));
        infoLine(c,"Медианный интервал",x.measuredIntervals==0?"—":minutes((int)Math.round(x.medianIntervalMin)));
        infoLine(c,"Самая длинная пауза",x.measuredIntervals==0?"—":minutes((int)Math.round(x.longestIntervalMin)));
        infoLine(c,"Соблюдение плана",x.measuredIntervals==0?"—":x.metPlan+" / "+x.measuredIntervals+" ("+(int)Math.round(x.adherencePercent)+"%)");
        infoLine(c,"Досрочных сеансов",String.valueOf(x.earlier));
        infoLine(c,"Расчётный никотин",x.estimatedSessions==0?"—":"≈"+mg(x.estimatedMg)+" мг");
        if(x.estimatedSessions>0&&x.estimatedSessions<x.sessions)c.addView(label("Оценка только по "+x.estimatedSessions+" из "+x.sessions+" сеансов: в старой истории нет надёжной дозы."));
        root.addView(c);
    }

    private void showSettings(){
        base("settings","Настройки","Устройство, план, сохранность данных.");
        LinearLayout device=card();title(device,"Устройство и оценка дозы");
        EditText name=edit(store.deviceName(),false),strength=edit(String.valueOf(store.strength()),true),volume=edit(String.valueOf(store.liquidMl()),true),
                puff=edit(String.valueOf(store.puffSeconds()),true),dose=edit(String.format(Locale.US,"%.3f",store.mgPerPuff()),true),ref=edit(String.valueOf(store.referencePuffs()),true);
        device.addView(field("Название",name));
        Spinner mode=spinner(new String[]{"ECO","Normal","Boost","Другой"},store.deviceMode());device.addView(field("Режим",mode));
        device.addView(field("Концентрация, мг/мл (проверь упаковку)",strength));
        device.addView(field("Объём жидкости, мл (справочно)",volume));
        device.addView(field("Длительность тяги, сек (справочно)",puff));
        device.addView(field("Обычный сеанс, тяг",ref));
        CheckBox enabled=new CheckBox(this);enabled.setText("Включить ручную оценку никотина");enabled.setTextColor(ink);enabled.setChecked(store.doseEstimateEnabled());device.addView(enabled);
        device.addView(field("Предполагаемый никотин, мг на затяжку",dose));
        device.addView(label("0,050 мг/тягу — НЕ лабораторно установленная доза VDOX. Она не рассчитывается автоматически по рекламному числу затяжек. При маркировке 0 мг/мл не включай расчёт с 20 мг/мл без проверки."));
        root.addView(device);

        LinearLayout plan=card();title(plan,"План интервалов");
        EditText start=edit(String.valueOf(store.startInterval()),true),target=edit(String.valueOf(store.targetInterval()),true),s1=edit(String.valueOf(store.stepBefore2h()),true),s2=edit(String.valueOf(store.stepAfter2h()),true);
        plan.addView(field("Начальная пауза, мин",start));plan.addView(field("Цель, мин",target));
        plan.addView(field("Шаг до 2 ч, мин",s1));plan.addView(field("Шаг после 2 ч, мин",s2));
        plan.addView(label("Новый этап предлагается после 5 успешных пауз подряд или 7 из 10. Переход только с подтверждением. Прежний этап сохранён при миграции."));
        root.addView(plan);

        LinearLayout notifications=card();title(notifications,"Шторка и внешний вид");
        CheckBox status=new CheckBox(this);status.setText("Постоянный таймер в шторке");status.setTextColor(ink);status.setChecked(store.statusNotificationEnabled());notifications.addView(status);
        Spinner theme=spinner(new String[]{"Системная","Светлая","Тёмная"},store.theme().equals("dark")?"Тёмная":store.theme().equals("light")?"Светлая":"Системная");
        notifications.addView(field("Оформление",theme));root.addView(notifications);
        Button save=button("Сохранить настройки",true);root.addView(save);
        save.setOnClickListener(v->{
            double strengthValue=readDouble(strength,store.strength()),volumeValue=readDouble(volume,store.liquidMl()),mgValue=readDouble(dose,store.mgPerPuff());
            if(strengthValue<0||strengthValue>100||volumeValue<0||volumeValue>200||mgValue<0||mgValue>10){Toast.makeText(this,"Проверь значения никотина и объёма",Toast.LENGTH_LONG).show();return;}
            if(strengthValue==0 && enabled.isChecked() && mgValue>0){Toast.makeText(this,"При 0 мг/мл оценка никотина за затяжку должна быть 0",Toast.LENGTH_LONG).show();return;}
            store.setDeviceName(name.getText().toString().trim().isEmpty()?"Одноразка":name.getText().toString().trim());
            store.setDeviceMode(mode.getSelectedItem().toString());store.setStrength(strengthValue);store.setLiquidMl(volumeValue);
            store.setPuffSeconds(Math.max(0.5,readDouble(puff,2)));store.setReferencePuffs(Math.max(1,readInt(ref,9)));
            store.setMgPerPuff(mgValue);store.setDoseEstimateEnabled(enabled.isChecked());
            store.setStartInterval(Math.max(15,readInt(start,60)));store.setTargetInterval(Math.max(store.startInterval(),readInt(target,240)));
            store.setStepBefore2h(Math.max(5,readInt(s1,15)));store.setStepAfter2h(Math.max(5,readInt(s2,30)));
            store.setStatusNotificationEnabled(status.isChecked());
            String choice=theme.getSelectedItem().toString();store.setTheme("Тёмная".equals(choice)?"dark":"Светлая".equals(choice)?"light":"system");
            if(!store.programStarted())store.setManualStageInterval(store.startInterval());
            if(status.isChecked())safeStartService();else StatusService.stop(this);
            Toast.makeText(this,"Настройки сохранены",Toast.LENGTH_SHORT).show();showSettings();
        });pad(root,14);
        LinearLayout backup=card();title(backup,"Резервная копия");
        backup.addView(label("Перед переустановкой или сменой телефона сохрани JSON. При обновлении APK поверх установленного приложения история остаётся автоматически, если совпадает подпись."));pad(backup,10);
        Button export=button("Экспорт истории и настроек",false);export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"nicotine-intervals-backup.json");startActivityForResult(i,EXPORT);});backup.addView(export);pad(backup,9);
        Button imp=button("Импорт резервной копии",false);imp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,IMPORT);});backup.addView(imp);root.addView(backup);
        LinearLayout danger=card();title(danger,"Сброс");Button clear=button("Удалить все записи и прогресс",false);
        clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Удалить историю?")
                .setMessage("Действие необратимо без резервной копии.")
                .setPositiveButton("Удалить",(d,w)->{store.clearSessions();store.setProgramStarted(false);store.setProgramStart(0);store.setManualStageInterval(store.startInterval());store.setStageStartTime(0);AlarmScheduler.cancel(this);StatusService.stop(this);showHome();})
                .setNegativeButton("Отмена",null).show());danger.addView(clear);root.addView(danger);
    }
    private Spinner spinner(String[] items,String selected){Spinner s=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);s.setAdapter(adapter);for(int i=0;i<items.length;i++)if(items[i].equalsIgnoreCase(selected))s.setSelection(i);return s;}
    private View field(String caption,View view){LinearLayout v=column();v.setPadding(0,dp(7),0,dp(8));v.addView(label(caption));v.addView(view);return v;}
    private EditText edit(String text,boolean numeric){EditText e=new EditText(this);e.setSingleLine(true);e.setText(text);e.setTextColor(ink);e.setTextSize(16);if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);return e;}
    private double readDouble(EditText v,double def){try{return Double.parseDouble(v.getText().toString().trim().replace(',','.'));}catch(Exception ignored){return def;}}
    private int readInt(EditText v,int def){try{return Integer.parseInt(v.getText().toString().trim());}catch(Exception ignored){return def;}}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        try {
            if(request==EXPORT){
                try(OutputStream output=getContentResolver().openOutputStream(data.getData())){
                    if(output==null)throw new Exception("Не удалось открыть файл");
                    output.write(store.exportBackup().toString(2).getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this,"Резервная копия сохранена",Toast.LENGTH_LONG).show();
            } else if(request==IMPORT){
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                try(InputStream in=getContentResolver().openInputStream(data.getData())){
                    if(in==null)throw new Exception("Не удалось прочитать файл");
                    byte[] buffer=new byte[8192];int n;
                    while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>10_000_000)throw new Exception("Файл слишком большой");}
                }
                final String json=bytes.toString("UTF-8");
                JSONObject backup=new JSONObject(json);
                if(!"NicotineIntervals".equals(backup.optString("app"))||backup.optInt("schema")!=2||!backup.has("prefs"))throw new Exception("Неверный файл");
                new AlertDialog.Builder(this).setTitle("Восстановить данные?")
                        .setMessage("Текущая история и настройки будут заменены данными из копии. Продолжить?")
                        .setPositiveButton("Восстановить",(d,w)->{try{store.importBackup(json);AlarmScheduler.cancel(this);List<Session> ss=store.getSessions();if(!ss.isEmpty()){Session last=ss.get(ss.size()-1);long due=last.timestamp+last.plannedIntervalMin*60000L;if(due>System.currentTimeMillis())AlarmScheduler.schedule(this,due);}if(store.statusNotificationEnabled())safeStartService();else StatusService.stop(this);showHome();Toast.makeText(this,"Данные восстановлены",Toast.LENGTH_LONG).show();}catch(Exception ex){new AlertDialog.Builder(this).setMessage(ex.getMessage()).setPositiveButton("OK",null).show();}})
                        .setNegativeButton("Отмена",null).show();
            }
        }catch(Exception ex){new AlertDialog.Builder(this).setTitle("Ошибка файла").setMessage(ex.getMessage()).setPositiveButton("OK",null).show();}
    }
}
