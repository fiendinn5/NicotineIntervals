package ru.vitaliy.nicotineintervals;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.List;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        AppStore store = new AppStore(context);
        if (!store.programStarted()) return;
        List<Session> sessions = store.getSessions();
        if (sessions.isEmpty()) return;
        Session last = sessions.get(sessions.size()-1);
        int interval = last.plannedIntervalMin;
        long due = last.timestamp + interval * 60_000L;
        if (due > System.currentTimeMillis()) AlarmScheduler.schedule(context, due);
        // BOOT_COMPLETED is an allowed background-start exception; specialUse is not among
        // Android 15's boot-blocked foreground-service types. Still catch OEM restrictions.
        try { StatusService.start(context); } catch (Exception ignored) {}
    }
}
