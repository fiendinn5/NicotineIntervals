package ru.vitaliy.nicotineintervals;

import java.util.List;

/**
 * An EXPLORATORY, NON-CLINICAL index of RECENT nicotine-use intensity.
 *
 * This index is not a measurement or prediction of vascular constriction,
 * endothelial function, blood pressure, pulse, individual cardiovascular risk,
 * or systemic nicotine concentration. It cannot quantify vascular damage.
 *
 * All calibration constants (0.35 mg reference dose, 45-minute effect half-time,
 * 20/40/60/80 display bands) are UX/model assumptions, NOT validated
 * nicotine dose-response or vascular-recovery parameters. The input mg/puff
 * is manually estimated and is not necessarily the absorbed systemic dose.
 */
public final class VascularImpactIndex {
    private VascularImpactIndex() {}

    /** Display-only assumptions: not a clinical dose-response curve. */
    public static final double REFERENCE_DOSE_MG = 0.35;
    public static final double EFFECT_HALF_TIME_MINUTES = 45.0;
    public static final long MINUTE_MS = 60_000L;
    public static final long EFFECT_WINDOW_MS = 12L * 60L * MINUTE_MS;
    public static final long COMPLETENESS_WINDOW_MS = 8L * 60L * MINUTE_MS;

    public static final class Snapshot {
        public final int score;
        public final int missingRecentDoses;
        public final int validDoses;
        public final boolean hasRecentSessions;
        public final long lastSessionTime;
        public final int lastPuffs;
        public final Double lastDoseMg;
        private final double[] doses;
        private final double[] agesInMinutes;

        private Snapshot(int score, int missing, int valid, boolean recent,
                         long lastTime, int lastPuffs, Double lastDose,
                         double[] doses, double[] agesInMinutes) {
            this.score = score;
            this.missingRecentDoses = missing;
            this.validDoses = valid;
            this.hasRecentSessions = recent;
            this.lastSessionTime = lastTime;
            this.lastPuffs = lastPuffs;
            this.lastDoseMg = lastDose;
            this.doses = doses;
            this.agesInMinutes = agesInMinutes;
        }

        public boolean canShowIndex() {
            return hasRecentSessions && missingRecentDoses == 0 && validDoses > 0;
        }

        /** Illustrative projection if no additional sessions occur. */
        public int afterMinutes(double additionalMinutes) {
            return combine(doses, agesInMinutes, Math.max(0, additionalMinutes));
        }
    }

    /** Illustrative one-session maximum, bounded to 0..100. */
    public static double peak(double estimatedDoseMg) {
        if (!Double.isFinite(estimatedDoseMg) || estimatedDoseMg <= 0) return 0;
        return Math.min(100.0, 100.0 * -Math.expm1(-estimatedDoseMg / REFERENCE_DOSE_MG));
    }

    private static int combine(double[] doses, double[] ages, double addedMinutes) {
        double notAffectedFraction = 1.0;
        for (int i = 0; i < doses.length; i++) {
            double contribution = peak(doses[i]) * Math.pow(0.5,
                    (ages[i] + addedMinutes) / EFFECT_HALF_TIME_MINUTES) / 100.0;
            // Multiplicative saturation ensures score cannot exceed 100.
            notAffectedFraction *= 1.0 - Math.max(0.0, Math.min(1.0, contribution));
        }
        return (int) Math.round(Math.max(0.0,
                Math.min(100.0, 100.0 * (1.0 - notAffectedFraction))));
    }

    public static Snapshot snapshot(List<Session> sessions, long now) {
        java.util.ArrayList<Double> doses = new java.util.ArrayList<>();
        java.util.ArrayList<Double> ages = new java.util.ArrayList<>();
        int missing = 0;
        int valid = 0;
        boolean recent = false;
        long latest = -1;
        int lastPuffs = 0;
        Double lastDose = null;
        for (Session s : sessions) {
            if (s.timestamp <= 0 || s.timestamp > now) continue;
            if (s.timestamp > latest) {
                latest = s.timestamp;
                lastPuffs = s.puffs;
                lastDose = s.estimatedNicotineMg;
            }
            long ageMs = now - s.timestamp;
            if (ageMs > EFFECT_WINDOW_MS) continue;
            recent = true;
            Double dose = s.estimatedNicotineMg;
            if (dose == null || !Double.isFinite(dose) || dose < 0) {
                if (ageMs <= COMPLETENESS_WINDOW_MS) missing++;
                continue;
            }
            // Zero nicotine is a valid dose; zero index is not a safety claim.
            valid++;
            doses.add(dose);
            ages.add(ageMs / (double) MINUTE_MS);
        }
        double[] ds = new double[doses.size()];
        double[] ts = new double[ages.size()];
        for (int i = 0; i < ds.length; i++) {
            ds[i] = doses.get(i);
            ts[i] = ages.get(i);
        }
        return new Snapshot(combine(ds, ts, 0), missing, valid, recent,
                latest, lastPuffs, lastDose, ds, ts);
    }

    public static String level(int score) {
        if (score <= 20) return "Низкий";
        if (score <= 40) return "Слабый";
        if (score <= 60) return "Умеренный";
        if (score <= 80) return "Высокий";
        return "Очень высокий";
    }
}
