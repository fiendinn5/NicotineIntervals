package ru.vitaliy.nicotineintervals;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AppStore {
    private static final String PREFS = "nicotine_intervals";
    private static final String KEY_SESSIONS = "sessions_json";
    private final SharedPreferences prefs;

    public AppStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        migrateStageV2();
    }

    public SharedPreferences prefs() { return prefs; }

    public List<Session> getSessions() {
        List<Session> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(KEY_SESSIONS, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) out.add(Session.fromJson(o));
            }
        } catch (Exception ignored) {}
        Collections.sort(out, Comparator.comparingLong(s -> s.timestamp));
        return out;
    }

    public void saveSessions(List<Session> sessions) {
        JSONArray arr = new JSONArray();
        for (Session s : sessions) {
            try { arr.put(s.toJson()); } catch (Exception ignored) {}
        }
        prefs.edit().putString(KEY_SESSIONS, arr.toString()).apply();
    }

    public void addSession(Session s) {
        List<Session> list = getSessions();
        list.add(s);
        saveSessions(list);
    }

    public void removeSession(long timestamp) {
        List<Session> current=getSessions();
        for(int i=0;i<current.size();i++) if(current.get(i).timestamp==timestamp) {current.remove(i);break;}
        saveSessions(current);
    }

    public void clearSessions() {
        prefs.edit().putString(KEY_SESSIONS, "[]").apply();
    }

    public String deviceType() { return prefs.getString("device_type", "Одноразка"); }
    public void setDeviceType(String v) { prefs.edit().putString("device_type", v).apply(); }

    public double strength() { return Double.longBitsToDouble(prefs.getLong("strength_bits", Double.doubleToRawLongBits(20.0))); }
    public void setStrength(double v) { prefs.edit().putLong("strength_bits", Double.doubleToRawLongBits(v)).apply(); }

    public double puffSeconds() { return Double.longBitsToDouble(prefs.getLong("puff_sec_bits", Double.doubleToRawLongBits(2.0))); }
    public void setPuffSeconds(double v) { prefs.edit().putLong("puff_sec_bits", Double.doubleToRawLongBits(v)).apply(); }

    public int referencePuffs() { return prefs.getInt("reference_puffs", 5); }
    public void setReferencePuffs(int v) { prefs.edit().putInt("reference_puffs", v).apply(); }

    public int startInterval() { return prefs.getInt("start_interval", 60); }
    public void setStartInterval(int v) { prefs.edit().putInt("start_interval", v).apply(); }

    public int targetInterval() { return prefs.getInt("target_interval", 240); }
    public void setTargetInterval(int v) { prefs.edit().putInt("target_interval", v).apply(); }

    public int stepBefore2h() { return prefs.getInt("step_before_2h", 15); }
    public void setStepBefore2h(int v) { prefs.edit().putInt("step_before_2h", v).apply(); }

    public int stepAfter2h() { return prefs.getInt("step_after_2h", 30); }
    public void setStepAfter2h(int v) { prefs.edit().putInt("step_after_2h", v).apply(); }

    public int stageDays() { return prefs.getInt("stage_days", 2); }
    public void setStageDays(int v) { prefs.edit().putInt("stage_days", v).apply(); }

    public boolean autoProgress() { return prefs.getBoolean("auto_progress", true); }
    public void setAutoProgress(boolean v) { prefs.edit().putBoolean("auto_progress", v).apply(); }

    public boolean programStarted() { return prefs.getBoolean("program_started", false); }
    public void setProgramStarted(boolean v) { prefs.edit().putBoolean("program_started", v).apply(); }

    public long programStart() { return prefs.getLong("program_start", 0); }
    public void setProgramStart(long v) { prefs.edit().putLong("program_start", v).apply(); }

    public int manualStageInterval() { return prefs.getInt("manual_stage_interval", startInterval()); }
    public void setManualStageInterval(int v) { prefs.edit().putInt("manual_stage_interval", v).apply(); }

    public boolean statusNotificationEnabled() { return prefs.getBoolean("status_notification_enabled", true); }
    public void setStatusNotificationEnabled(boolean v) { prefs.edit().putBoolean("status_notification_enabled", v).apply(); }

    public double liquidMl(){return Double.longBitsToDouble(prefs.getLong("liquid_ml",Double.doubleToRawLongBits(20.0)));}
    public void setLiquidMl(double v){prefs.edit().putLong("liquid_ml",Double.doubleToRawLongBits(v)).apply();}

    public long stageStartTime(){return prefs.getLong("stage_start_time",0L);}
    public void setStageStartTime(long t){prefs.edit().putLong("stage_start_time",t).apply();}
    public String deviceName(){return prefs.getString("device_name","Одноразка");}
    public void setDeviceName(String v){prefs.edit().putString("device_name",v).apply();}
    public String deviceMode(){return prefs.getString("device_mode","ECO");}
    public void setDeviceMode(String v){prefs.edit().putString("device_mode",v).apply();}
    public double mgPerPuff(){return Double.longBitsToDouble(prefs.getLong("mg_per_puff",Double.doubleToRawLongBits(0.05)));}
    public void setMgPerPuff(double v){prefs.edit().putLong("mg_per_puff",Double.doubleToRawLongBits(v)).apply();}
    public boolean doseEstimateEnabled(){return prefs.getBoolean("dose_estimate_enabled",false);}
    public void setDoseEstimateEnabled(boolean v){prefs.edit().putBoolean("dose_estimate_enabled",v).apply();}
    public String theme(){return prefs.getString("ui_theme","system");}
    public void setTheme(String t){prefs.edit().putString("ui_theme",t).apply();}

    /** Convert previous day-based auto-stages to the SAME stage, now approved manually. */
    private void migrateStageV2(){
        if(prefs.getBoolean("stage_migrated_v2",false)) return;
        SharedPreferences.Editor edit=prefs.edit();
        if(programStarted() && autoProgress()) {
            java.util.List<Integer> stages=Model.stages(startInterval(),targetInterval(),stepBefore2h(),stepAfter2h());
            long begin=programStart();
            int index=begin>0?(int)Math.max(0,Math.min(stages.size()-1,
                    (System.currentTimeMillis()-begin)/(Math.max(1,stageDays())*86400000L))):0;
            edit.putInt("manual_stage_interval",stages.get(index));
            edit.putBoolean("auto_progress",false);
        }
        edit.putBoolean("stage_migrated_v2",true).apply();
    }

    public JSONObject exportBackup() throws JSONException {
        JSONObject out=new JSONObject(); out.put("schema",2); out.put("app","NicotineIntervals");
        JSONObject data=new JSONObject();
        for(Map.Entry<String,?> x:prefs.getAll().entrySet()) {
            Object value=x.getValue();
            if(value instanceof String || value instanceof Number || value instanceof Boolean) data.put(x.getKey(),value);
        }
        out.put("prefs",data); return out;
    }
    /** Replaces app data ONLY after the UI asks confirmation; JSON validated before modification. */
    public void importBackup(String json) throws JSONException {
        JSONObject out=new JSONObject(json);
        if(!"NicotineIntervals".equals(out.optString("app")) || out.optInt("schema")!=2) throw new JSONException("Неверный формат резервной копии");
        JSONObject data=out.getJSONObject("prefs");
        String sessions=data.optString(KEY_SESSIONS,"[]");
        JSONArray items=new JSONArray(sessions);
        if(items.length()>100000) throw new JSONException("Слишком много записей");
        for(int i=0;i<items.length();i++) {
            JSONObject item=items.getJSONObject(i);
            if(item.optLong("timestamp",0)<=0 || item.optInt("puffs",0)<1) throw new JSONException("Повреждённая история");
        }
        SharedPreferences.Editor edit=prefs.edit().clear();
        java.util.Iterator<String> keys=data.keys();
        while(keys.hasNext()) {
            String key=keys.next(); Object value=data.opt(key);
            if(value instanceof Boolean)edit.putBoolean(key,(Boolean)value);
            else if(value instanceof String)edit.putString(key,(String)value);
            else if(value instanceof Integer)edit.putInt(key,(Integer)value);
            else if(value instanceof Long)edit.putLong(key,(Long)value);
            else if(value instanceof Number)edit.putLong(key,((Number)value).longValue());
        }
        edit.putBoolean("stage_migrated_v2",true).commit();
    }

    public long lastNotificationFor() { return prefs.getLong("last_notification_for", 0); }
    public void setLastNotificationFor(long v) { prefs.edit().putLong("last_notification_for", v).apply(); }
}
