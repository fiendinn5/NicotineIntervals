package ru.vitaliy.nicotineintervals;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.List;
import java.util.Locale;
import java.util.Calendar;

/**
 * User-visible foreground service that keeps a persistent status notification
 * in the notification shade. The native chronometer counts down continuously;
 * the modelled vascular/nicotine values are refreshed once per minute.
 */
public class StatusService extends Service {
    public static final String CHANNEL_ID = "live_status";
    public static final int NOTIFICATION_ID = 7101;
    private static final long UPDATE_MS = 60_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private AppStore store;
    private boolean foregroundStarted = false;

    public static void start(Context context) {
        AppStore store = new AppStore(context);
        if (!store.statusNotificationEnabled() || !store.programStarted() || store.getSessions().isEmpty()) return;
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        Intent i = new Intent(context, StatusService.class);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
        else context.startService(i);
    }

    public static void stop(Context context) {
        try { context.stopService(new Intent(context, StatusService.class)); } catch (Exception ignored) {}
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
    }

    @Override public void onCreate() {
        super.onCreate();
        store = new AppStore(this);
        ensureChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!store.statusNotificationEnabled() || !store.programStarted() || store.getSessions().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        Notification n = buildNotification(System.currentTimeMillis());
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
        foregroundStarted = true;
        handler.removeCallbacks(updateRunnable);
        handler.postDelayed(updateRunnable, UPDATE_MS);
        return START_STICKY;
    }

    private final Runnable updateRunnable = new Runnable() {
        @Override public void run() {
            if (!store.statusNotificationEnabled() || !store.programStarted() || store.getSessions().isEmpty()) {
                stopSelf();
                return;
            }
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(System.currentTimeMillis()));
            handler.postDelayed(this, UPDATE_MS);
        }
    };

    private Notification buildNotification(long now) {
        List<Session> sessions = store.getSessions();
        Session last = sessions.get(sessions.size() - 1);
        int intervalMin = last.plannedIntervalMin;
        long due = last.timestamp + intervalMin * 60_000L;
        long remainingMs = due - now;

        StatsEngine.Stats daily = StatsEngine.since(sessions, StatsEngine.dayStart(now), StatsEngine.daysBefore(now, -1));

        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 7102, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        String dailyText = "Сегодня: " + daily.sessions + " сеансов · " + daily.puffs + " тяг";

        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .setShowWhen(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setSubText("Интервалы • " + formatMin(intervalMin));

        if (remainingMs > 0) {
            b.setContentTitle("До планового интервала")
                    .setContentText(dailyText)
                    .setWhen(due)
                    .setUsesChronometer(true)
                    .setChronometerCountDown(true);

            int totalSec = Math.max(1, intervalMin * 60);
            int elapsedSec = (int)Math.max(0, Math.min(totalSec, (now - last.timestamp) / 1000L));
            b.setProgress(totalSec, elapsedSec, false);
        } else {
            b.setContentTitle("Плановый интервал выдержан ✓")
                    .setContentText(dailyText)
                    .setWhen(due)
                    .setUsesChronometer(false)
                    .setProgress(0, 0, false);
        }

        if (Build.VERSION.SDK_INT >= 24) {
            b.setStyle(new Notification.BigTextStyle().bigText(
                    (remainingMs > 0 ? "Идёт отсчёт плановой паузы. " : "Плановая пауза выдержана. Можно продолжать её дальше. ")
                            + dailyText + "."));
        }
        return b.build();
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Текущий статус",
                NotificationManager.IMPORTANCE_LOW);
        c.setDescription("Постоянный таймер паузы и количество записанных сеансов и тяг");
        c.setShowBadge(false);
        c.enableVibration(false);
        c.setSound(null, null);
        if (nm != null) nm.createNotificationChannel(c);
    }

    private String formatMin(int m) {
        if (m < 60) return m + " мин";
        int h = m / 60, r = m % 60;
        return r == 0 ? h + " ч" : h + " ч " + r + " мин";
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(updateRunnable);
        if (foregroundStarted) {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
            else stopForeground(true);
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
