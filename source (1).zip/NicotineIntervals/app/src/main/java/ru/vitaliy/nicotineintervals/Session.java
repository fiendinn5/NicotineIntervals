package ru.vitaliy.nicotineintervals;

import org.json.JSONException;
import org.json.JSONObject;

/** An immutable-in-history snapshot of the device/plan used at the moment of logging. */
public class Session {
    public long timestamp;
    public int puffs;
    public double strengthMgMl;
    public String deviceType;
    public double puffSeconds;
    public int plannedIntervalMin;
    public String deviceName;
    public String deviceMode;
    public Double mgPerPuff; // null for legacy/unverified estimates
    public Double estimatedNicotineMg; // content estimate, NOT absorbed systemic dose

    public Session(long timestamp, int puffs, double strengthMgMl, String deviceType,
                   double puffSeconds, int plannedIntervalMin) {
        this.timestamp=timestamp;
        this.puffs=puffs;
        this.strengthMgMl=strengthMgMl;
        this.deviceType=deviceType;
        this.puffSeconds=puffSeconds;
        this.plannedIntervalMin=plannedIntervalMin;
        this.deviceName=deviceType;
        this.deviceMode="";
        this.mgPerPuff=null;
        this.estimatedNicotineMg=null;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o=new JSONObject();
        o.put("timestamp",timestamp);
        o.put("puffs",puffs);
        o.put("strengthMgMl",strengthMgMl);
        o.put("deviceType",deviceType);
        o.put("puffSeconds",puffSeconds);
        o.put("plannedIntervalMin",plannedIntervalMin);
        o.put("deviceName",deviceName);
        o.put("deviceMode",deviceMode);
        if(mgPerPuff!=null) o.put("mgPerPuff",mgPerPuff);
        if(estimatedNicotineMg!=null) o.put("estimatedNicotineMg",estimatedNicotineMg);
        return o;
    }

    public static Session fromJson(JSONObject o) {
        Session s=new Session(o.optLong("timestamp",0),o.optInt("puffs",5),
                o.optDouble("strengthMgMl",20.0),o.optString("deviceType","Одноразка"),
                o.optDouble("puffSeconds",2.0),o.optInt("plannedIntervalMin",60));
        s.deviceName=o.optString("deviceName",s.deviceType);
        s.deviceMode=o.optString("deviceMode","");
        if(o.has("mgPerPuff") && !o.isNull("mgPerPuff")) s.mgPerPuff=o.optDouble("mgPerPuff");
        if(o.has("estimatedNicotineMg") && !o.isNull("estimatedNicotineMg"))
            s.estimatedNicotineMg=o.optDouble("estimatedNicotineMg");
        return s;
    }
}
