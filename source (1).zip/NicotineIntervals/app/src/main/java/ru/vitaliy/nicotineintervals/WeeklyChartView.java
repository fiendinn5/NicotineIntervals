package ru.vitaliy.nicotineintervals;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Seven local-calendar-day bars for factual recorded puff counts. */
public class WeeklyChartView extends View {
    public static final int PUFFS=0,INTERVALS=1;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final double[] values=new double[7];
    private final String[] labels=new String[7];
    private int ink=Color.rgb(44,53,74),bar=Color.rgb(78,116,232);
    public WeeklyChartView(Context context,List<Session> sessions,long now,int inkColor,int barColor,int metric) {
        super(context); ink=inkColor; bar=barColor;
        SimpleDateFormat format=new SimpleDateFormat("EE",Locale.getDefault());
        for(int i=0;i<7;i++) {
            long start=StatsEngine.daysBefore(now,6-i);
            long end=i==6?StatsEngine.daysBefore(now,-1):StatsEngine.daysBefore(now,5-i);
            labels[i]=format.format(new Date(start));
            if(metric==PUFFS) for(Session s:sessions) if(s.timestamp>=start && s.timestamp<end) values[i]+=s.puffs;
            else {
                StatsEngine.Stats daily=StatsEngine.since(sessions,start,end);
                values[i]=daily.avgIntervalMin;
            }
        }
        setMinimumHeight(dp(180));
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float l=dp(8),r=getWidth()-dp(8),top=dp(15),bottom=getHeight()-dp(38);
        if(r<=l||bottom<=top)return;
        double max=1; for(double v:values)max=Math.max(max,v);
        float slot=(r-l)/7;
        paint.setColor(ink);paint.setTextSize(dp(12));paint.setTextAlign(Paint.Align.CENTER);
        for(int i=0;i<7;i++) {
            float x=l+slot*(i+.5f),h=(float)((bottom-top)*values[i]/max);
            paint.setColor(bar);
            c.drawRoundRect(x-slot*.29f,bottom-h,x+slot*.29f,bottom,dp(7),dp(7),paint);
            paint.setColor(ink);paint.setTextSize(dp(11));
            if(values[i]>0) c.drawText(String.valueOf((int)values[i]),x,Math.max(top+dp(11),bottom-h-dp(6)),paint);
            c.drawText(labels[i],x,bottom+dp(22),paint);
        }
    }
}
