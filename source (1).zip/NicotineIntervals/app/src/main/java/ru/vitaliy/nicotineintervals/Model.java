package ru.vitaliy.nicotineintervals;

import java.util.ArrayList;
import java.util.List;

public class Model {
    public static List<Integer> stages(int start,int target,int stepBefore,int stepAfter) {
        List<Integer> list=new ArrayList<>();
        int x=Math.max(15,start), t=Math.max(x,target); list.add(x);
        int guard=0;
        while(x<t && guard++<100) {
            x=Math.min(t,x+(x<120?Math.max(5,stepBefore):Math.max(5,stepAfter)));
            list.add(x);
        }
        return list;
    }
    public static int currentStageIndex(AppStore store,long now) {
        List<Integer> stages=stages(store.startInterval(),store.targetInterval(),store.stepBefore2h(),store.stepAfter2h());
        if(!store.programStarted()) return 0;
        int val=store.manualStageInterval(),idx=0;
        for(int i=0;i<stages.size();i++) if(stages.get(i)<=val) idx=i;
        return idx;
    }
    public static int currentInterval(AppStore store,long now) {
        List<Integer> st=stages(store.startInterval(),store.targetInterval(),store.stepBefore2h(),store.stepAfter2h());
        return st.get(currentStageIndex(store,now));
    }
}
