package ru.vitaliy.nicotineintervals;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class SessionReadyReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "session_ready";

    @Override
    public void onReceive(Context context, Intent intent) {
        AppStore store = new AppStore(context);
        long now = System.currentTimeMillis();
        store.setLastNotificationFor(now);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Интервалы", NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("Уведомление, когда запланированный интервал завершён");
            nm.createNotificationChannel(c);
        }
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(context, 7002, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Плановая пауза выдержана")
                .setContentText("Ты выдержал плановую паузу. Если получится, продолжай без новой затяжки.")
                .setContentIntent(content)
                .setAutoCancel(true)
                .setShowWhen(true);
        nm.notify(7003, b.build());
    }
}
