package ru.vitaliy.nicotineintervals;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Behavioral statistics use actual recorded session timestamps, never modeled vessel percentages. */
public class StatsEngine {
    public static class Stats {
        public int sessions, puffs, measuredIntervals, metPlan, earlier, estimatedSessions;
        public double avgIntervalMin, longestIntervalMin, medianIntervalMin, estimatedMg;
        public double adherencePercent;
    }

    public static long dayStart(long time) {
        Calendar c=Calendar.getInstance(); c.setTimeInMillis(time);
        c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0);
        c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        return c.getTimeInMillis();
    }

    public static long daysBefore(long today, int days) {
        Calendar c=Calendar.getInstance(); c.setTimeInMillis(dayStart(today));
        c.add(Calendar.DAY_OF_YEAR,-days);
        return c.getTimeInMillis();
    }

    public static Stats since(List<Session> all, long from, long to) {
        Stats result=new Stats();
        List<Session> chronological=new ArrayList<>(all);
        Collections.sort(chronological,Comparator.comparingLong(a->a.timestamp));
        List<Double> gaps=new ArrayList<>(); double sum=0;
        for(int i=0;i<chronological.size();i++) {
            Session s=chronological.get(i);
            if(s.timestamp<from || s.timestamp>=to) continue;
            result.sessions++; result.puffs+=s.puffs;
            if(s.estimatedNicotineMg!=null && Double.isFinite(s.estimatedNicotineMg) && s.estimatedNicotineMg>=0) {
                result.estimatedMg+=s.estimatedNicotineMg; result.estimatedSessions++;
            }
            if(i==0) continue;
            Session previous=chronological.get(i-1);
            if(previous.timestamp>=s.timestamp) continue;
            double gap=(s.timestamp-previous.timestamp)/60000.0;
            // Ignore implausible gaps >= 24h: likely tracker inactivity, not a comparable session interval.
            if(gap>24*60) continue;
            gaps.add(gap); sum+=gap;
            result.longestIntervalMin=Math.max(result.longestIntervalMin,gap);
            result.measuredIntervals++;
            if(gap+0.5>=previous.plannedIntervalMin) result.metPlan++;
            else result.earlier++;
        }
        if(!gaps.isEmpty()) {
            result.avgIntervalMin=sum/gaps.size();
            Collections.sort(gaps);
            int n=gaps.size();
            result.medianIntervalMin=n%2==1?gaps.get(n/2):(gaps.get(n/2-1)+gaps.get(n/2))/2;
            result.adherencePercent=100.0*result.metPlan/result.measuredIntervals;
        }
        return result;
    }

    public static boolean readyForNextStage(List<Session> sessions,int stageInterval,long stageStart) {
        if(sessions.size()<2) return false;
        int n=0, successes=0, streak=0;
        for(int i=sessions.size()-1;i>0 && n<10;i--) {
            Session s=sessions.get(i), prev=sessions.get(i-1);
            long gap=s.timestamp-prev.timestamp;
            if(gap<=0 || gap>24*60*60*1000L) continue;
            if(prev.plannedIntervalMin!=stageInterval || prev.timestamp<stageStart) continue;
            boolean good=gap+30_000L>=prev.plannedIntervalMin*60_000L;
            n++; if(good) successes++;
            if(n==1 || streak==n-1) { if(good) streak++; }
        }
        return streak>=5 || (n>=10 && successes>=7);
    }
}
