# No custom rules required for this dependency-free app.
