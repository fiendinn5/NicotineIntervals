package android.graphics;
public class Paint {
    public static final int ANTI_ALIAS_FLAG=1;
    public enum Align { LEFT, CENTER, RIGHT }
    public Paint(int flags) {}
    public void setColor(int v){}
    public void setTextSize(float v){}
    public void setTextAlign(Align v){}
}
