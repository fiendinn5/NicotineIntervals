package android.graphics;
import java.util.ArrayList;
import java.util.List;
public class Canvas {
    public List<String> texts=new ArrayList<>();
    public void drawRoundRect(float l,float t,float r,float b,float rx,float ry,Paint p){}
    public void drawText(String value,float x,float y,Paint p){texts.add(value);}
}
