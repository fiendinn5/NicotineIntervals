package android.view;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
public class View {
    protected Context context;
    public View(Context context){this.context=context;}
    public Resources getResources(){return context.getResources();}
    public void setMinimumHeight(int value) {}
    public int getWidth(){return 350;}
    public int getHeight(){return 188;}
    protected void onDraw(Canvas c) {}
}
