package ru.vitaliy.nicotineintervals;
public class Session {
 public long timestamp;
 public int puffs,plannedIntervalMin;
 public Double estimatedNicotineMg;
 public Session(long t,int p,int plan){ timestamp=t;puffs=p;plannedIntervalMin=plan; }
}
