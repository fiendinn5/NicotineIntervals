package ru.vitaliy.nicotineintervals;

import android.content.Context;
import android.graphics.Canvas;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;

public class WeeklyStatsTest {
  static int checks=0;
  static void check(boolean ok,String message){ checks++; if(!ok) throw new AssertionError(message); }
  static long time(int day,int hour,int minute){
    Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Europe/Moscow"));
    c.clear();c.set(2026,Calendar.OCTOBER,day,hour,minute);return c.getTimeInMillis();
  }
  static Session session(int day,int hour,int minute,int p){return new Session(time(day,hour,minute),p,60);}
  static void testChartAndBuckets(){
    long now=time(13,0,10);
    List<Session> history=new ArrayList<>(Arrays.asList(
      session(10,20,0,36),session(10,21,0,36), // Sat 72
      session(11,20,0,40),session(11,21,0,43), // Sun 83
      session(12,21,0,31),session(12,23,0,40), // Mon 71
      session(13,0,8,10)                         // Tue 10; completed 68-minute gap crossing midnight
    ));
    Collections.reverse(history); // input isn't guaranteed sorted
    WeeklyStats.Day[] days=WeeklyStats.lastSevenDays(history,now);
    check(days.length==7,"seven daily bins");
    check(days[3].puffs==72,"Saturday recorded puffs exactly 72");
    check(days[4].puffs==83,"Sunday recorded puffs exactly 83");
    check(days[5].puffs==71,"Monday recorded puffs exactly 71");
    check(days[6].puffs==10,"Tuesday recorded puffs exactly 10");
    check(days[6].sessions==1,"Tuesday one session");
    check(days[6].measuredIntervals==1,"Tuesday interval from previous day");
    check(Math.abs(days[6].meanIntervalMinutes-68.0)<0.0001,"Tuesday mean 68 mins");
    check(days[0].puffs==0 && days[1].puffs==0 && days[2].puffs==0,"no phantom records");
    Canvas puffCanvas=new Canvas();
    new WeeklyChartView(new Context(),history,now,0xffeeeeee,0xffaaaaff,WeeklyChartView.PUFFS).onDraw(puffCanvas);
    check(puffCanvas.texts.contains("72"),"draw actual Saturday puffs");
    check(puffCanvas.texts.contains("83"),"draw actual Sunday puffs");
    check(puffCanvas.texts.contains("71"),"draw actual Monday puffs");
    check(puffCanvas.texts.contains("10"),"draw actual Tuesday puffs");
    Canvas gapCanvas=new Canvas();
    new WeeklyChartView(new Context(),history,now,0xffeeeeee,0xffaaffaa,WeeklyChartView.INTERVALS).onDraw(gapCanvas);
    check(gapCanvas.texts.contains("1ч08"),"draw 68-minute gap at today's date");
    history.add(session(13,7,0,500)); // a future-dated import must not contaminate today's chart
    check(WeeklyStats.lastSevenDays(history,now)[6].puffs==10,"exclude future sessions");
  }
  static void testEmptyAndDuplicates(){
    long now=time(13,0,10);
    List<Session> onlyOne=Arrays.asList(session(13,0,8,9));
    WeeklyStats.Day[] day=WeeklyStats.lastSevenDays(onlyOne,now);
    check(day[6].puffs==9 && day[6].measuredIntervals==0,"one first session = no measured gap");
    Canvas gap=new Canvas();
    new WeeklyChartView(new Context(),onlyOne,now,0xeeeeee,0xffffff,WeeklyChartView.INTERVALS).onDraw(gap);
    check(gap.texts.contains("Паузы появятся после 2 сеансов"),"explain missing intervals");
    List<Session> duplicate=Arrays.asList(session(13,0,8,4),session(13,0,8,5));
    check(WeeklyStats.lastSevenDays(duplicate,now)[6].puffs==9,"count recorded puffs even at same timestamp");
    check(WeeklyStats.lastSevenDays(duplicate,now)[6].measuredIntervals==0,"no invented zero-minute intervals");
  }
  static void testCalendarBoundaries(){
    long now=time(13,0,10);
    List<Session> h=Arrays.asList(session(12,23,58,5),session(13,0,1,9));
    WeeklyStats.Day[] days=WeeklyStats.lastSevenDays(h,now);
    check(days[5].puffs==5 && days[6].puffs==9,"puffs belong to local recorded date");
    check(days[6].measuredIntervals==1 && days[6].meanIntervalMinutes==3.0,"3-minute midnight interval belongs to day of second session");
    List<Session> far=Arrays.asList(session(10,2,0,3),session(13,0,1,9));
    check(WeeklyStats.lastSevenDays(far,now)[6].measuredIntervals==0,"do not misrepresent 3-day break as a single interval");
  }
  public static void main(String[] args){TimeZone.setDefault(TimeZone.getTimeZone("Europe/Moscow"));
    testChartAndBuckets(); testEmptyAndDuplicates();testCalendarBoundaries();
    System.out.println("OK: "+checks+" statistics and rendering checks passed");
  }
}
