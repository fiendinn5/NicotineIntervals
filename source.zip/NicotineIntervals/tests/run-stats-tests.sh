#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PROJ="$(cd "$HERE/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
JAVA="${PROJ}/app/src/main/java/ru/vitaliy/nicotineintervals"
find "$HERE/stubs" -name '*.java' -print > "$OUT/list"
printf '%s\n' "$JAVA/StatsEngine.java" "$JAVA/WeeklyStats.java" "$JAVA/WeeklyChartView.java" "$HERE/WeeklyStatsTest.java" >> "$OUT/list"
javac -d "$OUT" @"$OUT/list"
java -cp "$OUT" ru.vitaliy.nicotineintervals.WeeklyStatsTest
