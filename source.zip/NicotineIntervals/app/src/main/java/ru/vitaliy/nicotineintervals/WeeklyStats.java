package ru.vitaliy.nicotineintervals;

import java.util.List;

/** The same real-session calculations as the Today/7-day summaries, bucketed by local calendar day. */
public final class WeeklyStats {
    private WeeklyStats() {}

    public static final class Day {
        public final long fromInclusive, toExclusive;
        public final int sessions, puffs, measuredIntervals;
        public final double meanIntervalMinutes;

        private Day(long from, long to, StatsEngine.Stats data) {
            fromInclusive = from;
            toExclusive = to;
            sessions = data.sessions;
            puffs = data.puffs;
            measuredIntervals = data.measuredIntervals;
            meanIntervalMinutes = data.avgIntervalMin;
        }
    }

    /** Seven local dates, oldest first; today's date ends at now, not tomorrow. */
    public static Day[] lastSevenDays(List<Session> sessions, long now) {
        Day[] result = new Day[7];
        for (int i = 0; i < result.length; i++) {
            long start = StatsEngine.daysBefore(now, 6 - i);
            long dayEnd = StatsEngine.daysBefore(now, 5 - i);
            long end = i == 6 ? Math.min(dayEnd, now + 1L) : dayEnd;
            StatsEngine.Stats stats = StatsEngine.since(sessions, start, end);
            result[i] = new Day(start, end, stats);
        }
        return result;
    }
}
