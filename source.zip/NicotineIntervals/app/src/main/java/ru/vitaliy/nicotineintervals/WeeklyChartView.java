package ru.vitaliy.nicotineintervals;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Factual seven-day plots. A missing measured gap is NOT a zero-minute gap. */
public class WeeklyChartView extends View {
    public static final int PUFFS = 0, INTERVALS = 1;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final double[] values = new double[7];
    private final boolean[] hasObservation = new boolean[7];
    private final String[] labels = new String[7];
    private final int metric;
    private final int ink, bar;

    public WeeklyChartView(Context context, List<Session> sessions, long now,
                           int inkColor, int barColor, int metric) {
        super(context);
        if (metric != PUFFS && metric != INTERVALS) throw new IllegalArgumentException("Unknown chart metric");
        this.metric = metric;
        ink = inkColor;
        bar = barColor;
        SimpleDateFormat dayFormatter = new SimpleDateFormat("EE", Locale.getDefault());
        WeeklyStats.Day[] days = WeeklyStats.lastSevenDays(sessions, now);
        for (int i = 0; i < days.length; i++) {
            WeeklyStats.Day day = days[i];
            labels[i] = dayFormatter.format(new Date(day.fromInclusive));
            if (metric == PUFFS) {
                values[i] = day.puffs;
                hasObservation[i] = day.sessions > 0;
            } else {
                values[i] = day.meanIntervalMinutes;
                hasObservation[i] = day.measuredIntervals > 0;
            }
        }
        setMinimumHeight(dp(180));
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private String valueLabel(double val) {
        if (metric == PUFFS) return String.valueOf((int) Math.round(val));
        long rounded = Math.round(val);
        if (val > 0 && rounded == 0) return "<1м";
        if (rounded < 60) return rounded + "м";
        return (rounded / 60) + "ч" + String.format(Locale.getDefault(), "%02d", rounded % 60);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = dp(8), right = getWidth() - dp(8);
        float top = dp(21), bottom = getHeight() - dp(38);
        if (right <= left || bottom <= top) return;
        double max = 0;
        boolean any = false;
        for (int i = 0; i < 7; i++) {
            if (hasObservation[i]) {
                any = true;
                max = Math.max(max, values[i]);
            }
        }
        max = Math.max(1, max);
        float slot = (right - left) / 7f;
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(11));
        for (int i = 0; i < 7; i++) {
            float x = left + slot * (i + .5f);
            if (hasObservation[i]) {
                float height = (float) ((bottom - top) * values[i] / max);
                if (values[i] > 0) {
                    paint.setColor(bar);
                    canvas.drawRoundRect(x - slot * .29f, bottom - height,
                            x + slot * .29f, bottom, dp(7), dp(7), paint);
                }
                paint.setColor(ink);
                paint.setTextSize(dp(11));
                canvas.drawText(valueLabel(values[i]), x,
                        Math.max(top + dp(12), bottom - height - dp(7)), paint);
            }
            paint.setColor(ink);
            paint.setTextSize(dp(11));
            canvas.drawText(labels[i], x, bottom + dp(22), paint);
        }
        if (!any) {
            paint.setColor(ink);
            paint.setTextSize(dp(12));
            canvas.drawText(metric == INTERVALS
                    ? "Паузы появятся после 2 сеансов"
                    : "Пока нет записей за эти 7 дней",
                    (left + right) / 2, (top + bottom) / 2, paint);
        }
    }
}
