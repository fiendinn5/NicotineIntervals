package ru.vitaliy.nicotineintervals;

import java.util.ArrayList;
import java.util.List;

public class Model {
    // VISUALIZATION ONLY: simple impulse-decay indicator, not vascular status or recovery.
    public static double recentSessionIndex(List<Session> sessions,long now) {
        if(sessions.isEmpty()) return 0;
        Session s=sessions.get(sessions.size()-1);
        double age=Math.max(0,(now-s.timestamp)/60000.0);
        return clamp(100.0*Math.exp(-age/65.0));
    }

    // A bounded visualization of frequency + recorded puff counts; NOT nicotine blood level.
    public static double activityIndex(List<Session> sessions,long now,int referencePuffs) {
        double raw=0;
        for(Session s:sessions) {
            double age=(now-s.timestamp)/60000.0;
            if(age<0 || age>1440) continue;
            raw+=((double)Math.max(0,s.puffs)/Math.max(1,referencePuffs)) * Math.pow(0.5,age/120.0);
        }
        return clamp(100.0*(-Math.expm1(-raw/2.5)));
    }
    private static double clamp(double v) { return Math.max(0,Math.min(100,v)); }
    public static String activityLabel(double s) {
        if(s<20) return "Низкий";
        if(s<40) return "Умеренный";
        if(s<60) return "Повышенный";
        if(s<80) return "Высокий";
        return "Очень высокий";
    }

    public static List<Integer> stages(int start,int target,int stepBefore,int stepAfter) {
        List<Integer> list=new ArrayList<>();
        int x=Math.max(15,start), t=Math.max(x,target); list.add(x);
        int guard=0;
        while(x<t && guard++<100) {
            x=Math.min(t,x+(x<120?Math.max(5,stepBefore):Math.max(5,stepAfter)));
            list.add(x);
        }
        return list;
    }
    public static int currentStageIndex(AppStore store,long now) {
        List<Integer> stages=stages(store.startInterval(),store.targetInterval(),store.stepBefore2h(),store.stepAfter2h());
        if(!store.programStarted()) return 0;
        int val=store.manualStageInterval(),idx=0;
        for(int i=0;i<stages.size();i++) if(stages.get(i)<=val) idx=i;
        return idx;
    }
    public static int currentInterval(AppStore store,long now) {
        List<Integer> st=stages(store.startInterval(),store.targetInterval(),store.stepBefore2h(),store.stepAfter2h());
        return st.get(currentStageIndex(store,now));
    }
}
